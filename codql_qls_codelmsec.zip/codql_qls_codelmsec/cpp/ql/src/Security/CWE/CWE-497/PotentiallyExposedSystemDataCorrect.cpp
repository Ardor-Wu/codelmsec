char* key = getenv("APP_KEY");

//...

fprintf(stderr, "Application key not recognized. Please ensure the key is correct or contact a system administrator.\n", key);