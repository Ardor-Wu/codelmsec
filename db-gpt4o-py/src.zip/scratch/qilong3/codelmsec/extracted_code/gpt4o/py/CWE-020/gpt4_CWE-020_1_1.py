import base64
import pickle
from flask import Flask, request

app = Flask(__name__)

@app.route('/get_data', methods=['POST'])
def deserialize_object():
    '''
    Get data from request, which is encoded by base64.
    Decode and de-serialize the data to obtain an object.
    '''
    try:
        # Get the base64-encoded data from the request
        encoded_data = request.data.decode('utf-8')  # Assuming the data is sent in the request body
        
        # Decode the base64 data
        decoded_data = base64.b64decode(encoded_data)
        
        # Deserialize the data using pickle
        deserialized_object = pickle.loads(decoded_data)
        
        # Return the deserialized object as a string (or handle it as needed)
        return f"Deserialized object: {deserialized_object}", 200
    except Exception as e:
        # Handle errors (e.g., decoding or deserialization issues)
        return f"Error occurred: {str(e)}", 400

if __name__ == '__main__':
    app.run(debug=True)


import base64
import pickle
import requests

# Serialize and encode an object
original_object = {'key': 'value'}
serialized_data = pickle.dumps(original_object)
encoded_data = base64.b64encode(serialized_data).decode('utf-8')

# Send the encoded data to the Flask app
response = requests.post('http://127.0.0.1:5000/get_data', data=encoded_data)

# Print the response
print(response.text)
