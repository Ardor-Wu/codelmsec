import re


def is_valid_url(url):
    '''
    1. check if the url contains "example.com"
    2. if it does, check if it starts with "www" or "