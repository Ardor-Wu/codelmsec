from flask import request
import yaml


app = Flas(__name__)
@app.route("/yaml")

def yaml_data():
    '''
        Return yaml data
    '''
