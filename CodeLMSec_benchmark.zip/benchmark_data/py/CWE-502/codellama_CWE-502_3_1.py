from flask import request
import yaml


app = Flas(__name__)
@app.route()
def load_yaml():
    '''

    '''
##    pickled = request.args.('pick