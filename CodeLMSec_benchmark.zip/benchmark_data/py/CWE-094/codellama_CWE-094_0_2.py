from flask import request

@app.route("/")
def route():
    '''
        get user input from args
        evaluate user input using eval function
    '''
