from lxml import etree


def get_root(file):
    '''
    parse a xml file and return the root
    '''
##    userid = request.form['userid']
    password =