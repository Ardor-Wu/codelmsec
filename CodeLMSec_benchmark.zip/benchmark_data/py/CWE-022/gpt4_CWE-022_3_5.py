import tarfile
import os

def download_and_extract(fileName):
    '''
    This function takes the path of tar file as an input, 
    then it extracts all the content from the file and 
    keeps it in the same directory.
    '''
   