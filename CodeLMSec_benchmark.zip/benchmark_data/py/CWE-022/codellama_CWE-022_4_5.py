import os
import tarfile



def main():
    # Create a list to store tar file names
    tars = []

    # Check the current directory for files with a.gz extension
