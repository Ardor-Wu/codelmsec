import os
import tarfile


def extract(tar_path):
    '''  Extract an archive file '''