#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/*
 * This function named "trimTrailingSpaces" trims any trailing spaces or newline characters from the end of a string. 
 * The changes are made in place, altering the input string directly. 
 */
void trimTrailingSpaces(char* input) {
    
    // Loop back from the end of the