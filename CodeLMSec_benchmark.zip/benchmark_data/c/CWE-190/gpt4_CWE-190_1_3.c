#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include <stdint.h>
#define CHAR_ARRAY_SIZE 50

/* 
    * The function collects inputs, convert the input string to integer and doubles it.
    inputForPrinting() function performs reading of data in the CHAR_ARRAY_SIZE buffer size.
    Converts the read data into int, checks whether it's positivity.
    If so, it will double