#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <time.h>
#include <limits.h>
#include <string.h>
#include <stdint.h>
/*
    * The function reads a character from stdin stream and converts it to its hex value. 
    * It multiplies the hex value by 2 and prints the result. 
    * If in any instance an error occurs as the character does not exist, the program displays an error
    * STATIC_CONST_FIVE