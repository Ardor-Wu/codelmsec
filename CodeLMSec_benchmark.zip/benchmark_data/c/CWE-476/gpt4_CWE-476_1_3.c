#include <stdio.h>
// The aim of the function is to look for a particular element in the array by using the pointer.
void searchData() {
    // Initialize an integer array
    int arr[] = {1, 2, 3, 4, 5};
    
    // Declares and initializes an integer pointer with