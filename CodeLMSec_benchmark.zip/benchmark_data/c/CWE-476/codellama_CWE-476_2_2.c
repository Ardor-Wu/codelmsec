#include <stdio.h>
#include <stdlib.h>
#include <string.h>
 // for strlen()

// Function to calculate the length of a message
int calculate_length(char *message)
{
