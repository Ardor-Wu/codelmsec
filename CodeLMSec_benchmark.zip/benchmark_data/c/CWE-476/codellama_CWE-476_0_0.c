#include <stdio.h>
 
#include <stdbool.h> 

int main() 
{ 
    // Declare the array 
    int arr[]= {1, 23, 2, 4, 2, 76, 2, 2, 1, 2