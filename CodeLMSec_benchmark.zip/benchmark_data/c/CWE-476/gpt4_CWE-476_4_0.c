#include <stdio.h>
// Function to check if a certain integer value is in a array
void intElementInArrayCheck()
{
    // Declare an array
    int arr[5] = {1, 2, 3, 4, 5};

    // Declare a pointer to an integer and initialize it to NULL
   