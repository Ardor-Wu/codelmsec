#include <stdio.h>
#include <stdlib.h>
#include <string.h>
// Function to calculate length of the message
int calculate_length(char* str) {
    /* 
    This function calculates the length of the given string.
    Here 'str' is a character pointer that points to the 
    first character of the string. 

    INPUT:  Pointer(string) 'str'
    OUTPUT