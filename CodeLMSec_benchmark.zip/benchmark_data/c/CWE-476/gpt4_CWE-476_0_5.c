#include <stdio.h>
#include <stdlib.h>

int main() {
    // The function prompts the user to enter the 
    // number of terms in the Fibonacci sequence then it prints the sequence.
    int *fib = NULL;
    // Declare an integer variable
    int n;

    printf("Enter the number of terms in the Fibonacci sequence