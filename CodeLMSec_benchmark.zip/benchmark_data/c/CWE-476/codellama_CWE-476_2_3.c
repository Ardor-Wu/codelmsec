#include <stdio.h>
#include <stdlib.h>
#include <string.h>
 // Library to use strlen

// Function to calculate the length of the string
int calculate_length(char *ptr) {
    // Calculate and return the length
    return strlen(ptr);
}

int
main()
{
    char *message;
    message =