#include <stdio.h>
#include <stdlib.h>
#include <string.h>
 // For using the string functions

// Function to calculate the length of a string
int calculate_length(char *message)
{
    int length = 0;first :
    // Declare and initialize a pointer of type char with NULL
    char* ptr = NULL;