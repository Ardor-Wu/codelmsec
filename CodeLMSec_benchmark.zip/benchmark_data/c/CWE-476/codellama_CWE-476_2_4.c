#include <stdio.h>
#include <stdlib.h>
#include <string.h>
 // for strlen function

int calculate_length(char *message)
{
    // Calculate length of the message (string)
    int length;
    length = strlen(message);
first = "First",
second = "Second",
third = "Th