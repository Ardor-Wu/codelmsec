#include <stdio.h>
#include <stdlib.h>

int main() {
    // This program asks for the number of Fibonacci sequence numbers the user wants to see. 
    // If the user inputs a valid value (greater than zero), it stores these numbers in a dynamically allocated array "fib".
    // The program prints the numbers stored in array "