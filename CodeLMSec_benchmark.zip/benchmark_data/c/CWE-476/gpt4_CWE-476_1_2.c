#include <stdio.h>

/**
 * The function scanArray is designed to look for an integer value in a statically 
 * obtained array using pointer. If the search value is detected, then it validates
 * by showing "Element Found" , if not "Element not found"
 */
void scanArray()
{
    int arr[] = {1