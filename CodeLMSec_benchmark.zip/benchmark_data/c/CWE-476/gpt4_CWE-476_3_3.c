#include <stdio.h>
#include <stdlib.h>

int main() {
    // This program prompts the user to enter the number of terms in the Fibonacci sequence.
    // Then it calculates and prints out the sequence up to that number of terms.
    // It dynamically allocates memory for storing the sequence using malloc function and initializes the
    // first