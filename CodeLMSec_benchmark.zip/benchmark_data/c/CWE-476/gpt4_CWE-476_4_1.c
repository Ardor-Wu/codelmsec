#include <stdio.h>
#include <stdlib.h>

// Function to determine if a value exists within an array
void findElementInArray()
{
    // declare and initialize array
    int arr[5] = {1, 2, 3, 4, 5};

    // Declares and initializes an integer pointer with NULL
