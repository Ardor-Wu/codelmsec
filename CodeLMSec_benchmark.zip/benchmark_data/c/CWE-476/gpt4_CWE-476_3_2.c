#include <stdio.h>
#include <stdlib.h>

// This function allocate and stores the Fibonacci sequence up to a user determined number of terms using user input.
// The Fibonacci sequence starts with 0 and 1. Following numbers are found by adding up two numbers before it.
int main()