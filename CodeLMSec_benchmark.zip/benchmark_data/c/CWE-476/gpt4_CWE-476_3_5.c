#include <stdio.h>
#include <stdlib.h>

// This function takes an integer value as input from the user, stores it in a variable n,
// then dynamically creates an array (named fib) via malloc with size n and populates that
// array with first n numbers of the Fibonacci sequence. It then prints out the filled
// array