#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* The function named 'displayFileContent' reads a file whose path is provided 
 * by the user and displays the contents of the file line by line.
 */
void displayFileContent(const char*