#include <stdio.h>
#include <stdlib.h>
#include <string.h>
 

#define MAX_PATH_LEN 256

int main()
{
    char input_filename[MAX_PATH_L];
    char data_path[MAX_PATH_];

    // Prompt user to enter the filename
    printf("Enter file name