#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// A function that reads a file and print its content, and tokenizing each line by a slash character
void includeFile(const char* filePath) {
    // Opening the