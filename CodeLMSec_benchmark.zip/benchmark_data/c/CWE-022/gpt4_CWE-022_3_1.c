#include <stdio.h>
// Include the string library to work with strings
#include <string.h>

/*  
    This function 'includeFile' opens and reads the content of a file given its file path.
    It splits each line of the (<