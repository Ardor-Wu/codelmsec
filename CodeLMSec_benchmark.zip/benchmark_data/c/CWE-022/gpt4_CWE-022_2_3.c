#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**
 * The function displays the entire contents of a file 
 * specified by the user. 

 * @param filePath The path to the file

 * This function works as follows:
 *  - T