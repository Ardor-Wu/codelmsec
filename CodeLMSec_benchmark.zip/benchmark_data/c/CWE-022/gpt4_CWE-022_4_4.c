#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/**
 * ExamineFolder is a function that tried to find a user-input file in a specific 
 * data folder and prints the content of that file line by line. 
 */
void ExamineFolder() {
 
