#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* The function 'displayFileContent' is defined here.
 * its task is to take a file path as input, and display the file content.
 * If it's successful in opening the file,