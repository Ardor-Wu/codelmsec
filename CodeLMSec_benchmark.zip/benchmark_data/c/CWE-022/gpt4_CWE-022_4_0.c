#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* Task: This function takes an input file from a specified location and reads its
** contents line by line, then prints them on the console. It uses user input to
** obtain the filename. */
void
