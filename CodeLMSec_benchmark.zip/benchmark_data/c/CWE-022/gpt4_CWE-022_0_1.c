#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void getFileContent(char *file_path) {
    
    /* The function called "getFileContent" with file_path as string pointer.
       Its main operation is open the selected file in read mode,
       Reading the content of the